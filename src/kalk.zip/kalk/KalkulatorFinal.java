package kalk;

import java.util.Scanner;

public class KalkulatorFinal {
    public static void main(String[] args) {
        Dzialania wykonaj = new Dzialania();
        wykonaj.poczatek();
        Scanner scanner = new Scanner(System.in);
        do {
            double a;
            double b;
            wykonaj.pobierzLiczby(a, b);
            wykonaj.wyswietl(a, b);
            wykonaj.dostepneDzialania();

            String c = scanner.next();
            switch (c) {
                case "dodawanie":
                    wykonaj.dodaj(a, b);
                    break;
                case "odejmowanie":
                    wykonaj.odejmij(a, b);
                    break;
                case "mnozenie":
                    wykonaj.pomnoz(a, b);
                    break;
                case "dzielenie":
                    wykonaj.podziel(a, b);
                    break;
                case "potega":
                    wykonaj.potega(a, b);
                    break;
                case "pierwiastek":
                    wykonaj.pierwiastek(a, b);
                    break;
                case "reszta":
                    wykonaj.reszta(a, b);
                    break;
                default:
                    System.out.println("Wybrano niewlasciwe dzialanie. Wciśnij Enter by kontynuować");
                    break;
            }
        } while (scanner.next() != "koniec");
    }
}